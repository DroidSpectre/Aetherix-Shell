# assets placeholder
No bundled assets in this edition: the shell runs the on-device
/system/bin/sh directly. This file keeps the directory tracked.
