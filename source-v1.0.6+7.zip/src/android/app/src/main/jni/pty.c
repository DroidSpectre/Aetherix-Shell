/* pty.c: openpty + fork + exec /bin/bash, winsize clamp, PDEATHSIG.
 * Why: mirrors hermes api/terminal.py (Queue 2000, 8-80x20-240, killpg).
 * No systemd on Android, so parent holds child via foreground service.
 */
#include <jni.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#ifdef __linux__
#include <pty.h>
#include <sys/prctl.h>
#endif

/* Versioned libc bindings: this library is built with -nostdlib (no NDK
 * import libs), so references default to UNVERSIONED symbols. The on-device
 * loader only binds the VERSIONED ones (ioctl was the first refusal), while
 * the NDK-built original references everything as sym@LIBC. Mirror that or
 * dlopen fails. One line per libc function this file calls. */
__asm__(".symver _exit,_exit@LIBC");
__asm__(".symver access,access@LIBC");
__asm__(".symver chdir,chdir@LIBC");
__asm__(".symver close,close@LIBC");
__asm__(".symver dup2,dup2@LIBC");
__asm__(".symver execl,execl@LIBC");
__asm__(".symver fcntl,fcntl@LIBC");
__asm__(".symver fork,fork@LIBC");
__asm__(".symver ioctl,ioctl@LIBC");
__asm__(".symver openpty,openpty@LIBC");
__asm__(".symver prctl,prctl@LIBC");
__asm__(".symver read,read@LIBC");
__asm__(".symver setenv,setenv@LIBC");
__asm__(".symver setsid,setsid@LIBC");
__asm__(".symver tcgetattr,tcgetattr@LIBC");
__asm__(".symver tcsetattr,tcsetattr@LIBC");
__asm__(".symver write,write@LIBC");

static int clamp_int(int v, int lo, int hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

jint Java_com_aetherix_shell_PtyBridge_openPty(JNIEnv* env, jobject thiz, jstring jcmd, jstring jcwd, jobjectArray jenv) {
    const char* cmd = (*env)->GetStringUTFChars(env, jcmd, 0);
    const char* cwd = (*env)->GetStringUTFChars(env, jcwd, 0);
    int master = -1;
    int slave = -1;
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = 24;
    ws.ws_col = 80;
    if (openpty(&master, &slave, 0, 0, &ws) != 0) {
        (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return -1;
    }
    int flags = fcntl(master, F_GETFL, 0);
    fcntl(master, F_SETFL, flags | O_NONBLOCK);
    pid_t pid = fork();
    if (pid < 0) {
        close(master);
        close(slave);
        (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
        (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
        return -1;
    }
    if (pid == 0) {
        setsid();
#ifdef TIOCSCTTY
        ioctl(slave, TIOCSCTTY, 0);
#endif
#ifdef __linux__
        prctl(PR_SET_PDEATHSIG, SIGHUP);
#endif
        /* Enforce known-good cooked mode: the slave may inherit odd flags
         * (missing ECHOE, or VERASE != DEL), which makes the shell ignore
         * backspace even though the byte arrives. Force ECHOE/ECHOK/ERASE=DEL. */
        {
            struct termios t;
            if (tcgetattr(slave, &t) == 0) {
                t.c_iflag |= (BRKINT | ISTRIP | ICRNL | IXON);
                t.c_oflag |= (OPOST | ONLCR);
                t.c_lflag |= (ECHO | ECHOE | ECHOK | ECHOCTL | ECHOKE | ICANON | ISIG | IEXTEN);
                t.c_cc[VERASE] = 127;
                t.c_cc[VKILL] = 21;
                t.c_cc[VINTR] = 3;
                t.c_cc[VQUIT] = 28;
                t.c_cc[VEOF] = 4;
                t.c_cc[VMIN] = 1;
                t.c_cc[VTIME] = 0;
                tcsetattr(slave, TCSANOW, &t);
            }
        }
        dup2(slave, 0);
        dup2(slave, 1);
        dup2(slave, 2);
        if (slave > 2) close(slave);
        close(master);
        if (cwd != 0 && cwd[0] != '\0') {
            chdir(cwd);
        }
        setenv("TERM", "xterm-256color", 1);
        setenv("COLORTERM", "truecolor", 1);
        /* Prefer the shell directly: one fewer process layer and no reliance
         * on a /bin/sh vendor symlink that is absent on many Android builds.
         * Fall back to the legacy wrapper path if it is not executable. */
        if (access("/system/bin/sh", X_OK) == 0) {
            execl("/system/bin/sh", "sh", "-l", (char*)0);
        }
        execl("/bin/sh", "sh", "-l", "-c", cmd, (char*)0);
        _exit(127);
    }
    close(slave);
    (*env)->ReleaseStringUTFChars(env, jcmd, cmd);
    (*env)->ReleaseStringUTFChars(env, jcwd, cwd);
    return master;
}

jint Java_com_aetherix_shell_PtyBridge_readPty(JNIEnv* env, jobject thiz, jint fd, jbyteArray buf, jint len) {    if (fd < 0 || buf == 0 || len <= 0) return -1;
    jbyte* p = (*env)->GetByteArrayElements(env, buf, 0);
    ssize_t r = read((int)fd, p, (size_t)len);
    (*env)->ReleaseByteArrayElements(env, buf, p, 0);
    if (r < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        return -1;
    }
    return (jint)r;
}

void Java_com_aetherix_shell_PtyBridge_resizePty(JNIEnv* env, jobject thiz, jint fd, jint rows, jint cols) {
    if (fd < 0) return;
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short)clamp_int(rows, 8, 80);
    ws.ws_col = (unsigned short)clamp_int(cols, 20, 240);
    ioctl((int)fd, TIOCSWINSZ, &ws);
}

void Java_com_aetherix_shell_PtyBridge_closePty(JNIEnv* env, jobject thiz, jint fd) {
    if (fd >= 0) close((int)fd);
}

jint Java_com_aetherix_shell_PtyBridge_writePty(JNIEnv* env, jobject thiz, jint fd, jbyteArray buf, jint len) {
    if (fd < 0 || buf == 0 || len <= 0) return -1;
    jbyte* p = (*env)->GetByteArrayElements(env, buf, 0);
    ssize_t w = write((int)fd, p, (size_t)len);
    (*env)->ReleaseByteArrayElements(env, buf, p, JNI_ABORT);
    if (w < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) return 0;
        return -1;
    }
    return (jint)w;
}
