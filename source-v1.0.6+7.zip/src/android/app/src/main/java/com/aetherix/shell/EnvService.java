package com.aetherix.shell;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import java.util.ArrayList;

/**
 * Foreground keep-alive.
 * Why foreground: Android kills background shell sessions without notification + Doze exemption.
 * Why START_STICKY: restart after kill, session restarts with the service.
 * No lambdas, no diamonds.
 */
public class EnvService extends Service {
    public static final String CHANNEL = "aetherix-shell";
    public static final int NOTIF_ID = 4201;

    public static void noteStarted(final Context ctx) {
        final ArrayList<String> log = new ArrayList<String>();
        log.add("EnvService noted");
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onCreate() {
        super.onCreate();
        CrashLog.install(this);
        EventLog.append(this, "service", "onCreate");
        try {
            ensureChannel();
            final Notification n = buildNotification();
            try {
                startForeground(NOTIF_ID, n);
                EventLog.append(EnvService.this, "service", "foreground ok");
            } catch (Exception e) {
                // API 34+ throws without FOREGROUND_SERVICE_SPECIAL_USE or on some OEMs.
                // Fall back to a plain notification so the app survives without FGS.
                EventLog.append(EnvService.this, "service", "foreground FAILED, notify fallback: " + String.valueOf(e.getMessage()));
                try {
                    final NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    nm.notify(NOTIF_ID, n);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            // Never let service creation crash the app; launcher shows crash.log.
            try {
                final java.io.File f = new java.io.File(getFilesDir(), CrashLog.NAME);
                final java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter(f, true));
                try {
                    pw.println("=== EnvService.onCreate guard ===");
                    e.printStackTrace(pw);
                } finally {
                    pw.close();
                }
            } catch (Exception ignored) {
            }
        }
    }

    public int onStartCommand(final Intent intent, int flags, int startId) {
        EventLog.append(this, "service", "start");
        // Own the shell session (Termux-style): activities attach for display.
        // Survives Back/task-swipe while this foreground service lives.
        // No bootstrap: this edition runs the on-device shell directly,
        // there is no rootfs to extract and no runtime to select.
        ShellSession.get().start(this);
        return START_STICKY;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            final NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            final NotificationChannel ch = new NotificationChannel(CHANNEL, "Aetherix-Shell", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            final Notification.Builder b = new Notification.Builder(this, CHANNEL);
            b.setContentTitle("Aetherix-Shell");
            b.setContentText("Linux environment running");
            b.setSmallIcon(android.R.drawable.stat_notify_sync);
            return b.build();
        } else {
            final Notification.Builder b = new Notification.Builder(this);
            b.setContentTitle("Aetherix-Shell");
            b.setContentText("Linux environment running");
            b.setSmallIcon(android.R.drawable.stat_notify_sync);
            return b.build();
        }
    }
}
