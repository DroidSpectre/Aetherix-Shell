package com.aetherix.shell;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * Append-only runtime event log (files/events.log, capped ~50KB with rotation).
 * Why: field debugging without logcat - the launcher shows the tail live,
 * copyable/shareable. CrashLog stays crash-only; this is lifecycle + bootstrap
 * + pty + paste breadcrumbs with timestamps.
 * No lambdas, no diamonds.
 */
public class EventLog {
    public static final String NAME = "events.log";
    public static final long MAX_BYTES = 50 * 1024;

    public static synchronized void append(Context ctx, String tag, String msg) {
        try {
            final File dir = ctx.getFilesDir();
            if (dir == null) {
                return;
            }
            final File f = new File(dir, NAME);
            if (f.exists() && f.length() > MAX_BYTES) {
                rotate(f);
            }
            final PrintWriter pw = new PrintWriter(new FileWriter(f, true));
            try {
                pw.println(String.valueOf(new java.util.Date()) + " [" + tag + "] " + msg);
            } finally {
                pw.close();
            }
        } catch (Exception ignored) {
        }
    }

    private static void rotate(File f) throws Exception {
        final BufferedReader br = new BufferedReader(new FileReader(f));
        try {
            final StringBuffer sb = new StringBuffer();
            final char[] buf = new char[4096];
            int r;
            while ((r = br.read(buf)) != -1) {
                sb.append(buf, 0, r);
            }
            final String all = sb.toString();
            final int keepFrom = Math.max(0, all.length() - (int) (MAX_BYTES / 2));
            final String tail = all.substring(keepFrom);
            final int nl = tail.indexOf('\n');
            final String trimmed = (nl >= 0 && keepFrom > 0) ? tail.substring(nl + 1) : tail;
            final PrintWriter pw = new PrintWriter(new FileWriter(f, false));
            try {
                pw.print(trimmed);
            } finally {
                pw.close();
            }
        } finally {
            br.close();
        }
    }

    public static String readTail(Context ctx, int maxChars) {
        try {
            final File f = new File(ctx.getFilesDir(), NAME);
            if (f.exists() == false) {
                return "";
            }
            final BufferedReader br = new BufferedReader(new FileReader(f));
            try {
                final StringBuffer sb = new StringBuffer();
                final char[] buf = new char[2048];
                int r;
                while ((r = br.read(buf)) != -1) {
                    sb.append(buf, 0, r);
                }
                final String all = sb.toString();
                if (all.length() <= maxChars) {
                    return all;
                }
                return all.substring(all.length() - maxChars);
            } finally {
                br.close();
            }
        } catch (Exception e) {
            return "event-log read error: " + String.valueOf(e.getMessage());
        }
    }
}
