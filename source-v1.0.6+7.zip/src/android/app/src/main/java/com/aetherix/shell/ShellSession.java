package com.aetherix.shell;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Shell session owned by the process, not the activity.
 * Why: Termux survives app/device state changes because sessions live in its
 * foreground service process, not in a destroyable activity. Ours died with
 * TerminalActivity (Back/task-swipe = fresh shell). Now EnvService starts the
 * session once; activities attach/detach for display without touching the fd.
 * Process death still ends it (same as Termux force-stop); service restart
 * recreates it via START_STICKY.
 * Holds: PtyBridge, fd, reader thread, transcript + display processing
 * (BS/CR/TAB/CSI, 100KB cap, CR-straddle state), main-thread listeners.
 * No lambdas, no diamonds.
 */
public class ShellSession {
    private static final int TRANSCRIPT_CAP = 100 * 1024;
    // Diagnostic tap: log every received chunk with visible escapes so a
    // one-enter test reveals exact wire bytes (lone CR? CSI? split pairs?).
    // Gated off: the blanking investigation is closed by field evidence
    // (v6-shell). Re-enable locally when diagnosing wire-level issues.
    private static final boolean TAP_RX = false;

    public interface Listener {
        void onOutput(String transcriptSnapshot);
        void onClosed();
    }

    private static ShellSession instance = null;

    public static synchronized ShellSession get() {
        if (instance == null) {
            instance = new ShellSession();
        }
        return instance;
    }

    private PtyBridge pty = null;
    private int fd = -1;
    private volatile boolean running = false;
    private final StringBuilder transcript = new StringBuilder();
    private boolean pendingCR = false;
    private final ArrayList<Listener> listeners = new ArrayList<Listener>();
    private Handler mainHandler = null;
    private Context appCtx = null;

    public synchronized boolean isRunning() {
        return running;
    }

    public synchronized void start(Context ctx) {
        if (running) {
            return;
        }
        if (PtyBridge.ensureLoaded() == false) {
            return;
        }
        appCtx = ctx.getApplicationContext();
        pty = new PtyBridge();
        try {
            fd = pty.openPty("/system/bin/sh", appCtx.getFilesDir().getAbsolutePath(), null);
        } catch (UnsatisfiedLinkError e) {
            // Java/native skew must degrade to a log line, never a crash loop.
            EventLog.append(appCtx, "pty", "native mismatch: " + String.valueOf(e.getMessage()));
            pty = null;
            fd = -1;
            return;
        }
        if (fd < 0) {
            EventLog.append(appCtx, "pty", "open FAILED");
            pty = null;
            return;
        }
        pty.resizePty(fd, 24, 80);
        mainHandler = new Handler(Looper.getMainLooper());
        running = true;
        // Fresh launch gets the banner; a restart after exit keeps the old
        // transcript (Back/reopen survival) with a separator instead of a
        // second banner glued to the prompt (v29 field report).
        if (transcript.length() == 0) {
            transcript.append("Aetherix-Shell\n");
        } else {
            transcript.append("\n[--- new shell ---]\n");
        }
        final Thread t = new Thread(new Runnable() {
            public void run() {
                readLoop();
            }
        });
        t.start();
        EventLog.append(appCtx, "pty", "open fd=" + fd);
    }

    public synchronized void attach(Listener l) {
        boolean found = false;
        for (int i = 0; i < listeners.size(); i++) {
            if (listeners.get(i) == l) {
                found = true;
            }
        }
        if (found == false) {
            listeners.add(l);
        }
        final String snap = transcript.toString();
        final Listener target = l;
        if (mainHandler != null) {
            mainHandler.post(new Runnable() {
                public void run() {
                    target.onOutput(snap);
                }
            });
        }
    }

    public synchronized void detach(Listener l) {
        for (int i = listeners.size() - 1; i >= 0; i--) {
            if (listeners.get(i) == l) {
                listeners.remove(i);
            }
        }
    }

    public synchronized int writeText(String s) {
        if (running == false || pty == null || fd < 0 || s == null) {
            return 0;
        }
        int wrote = 0;
        try {
            final byte[] b = s.getBytes("UTF-8");
            int off = 0;
            while (off < b.length) {
                final byte[] slice = java.util.Arrays.copyOfRange(b, off, b.length);
                final int r = pty.writePty(fd, slice, slice.length);
                if (r <= 0) {
                    break;
                }
                off += r;
            }
            wrote = off;
        } catch (Exception ignored) {
        }
        return wrote;
    }

    public synchronized int[] writeDel(int n) {
        final int[] res = new int[] { 0, 0 };
        if (running == false || pty == null || fd < 0) {
            return res;
        }
        final byte[] del = new byte[] { 127 };
        for (int i = 0; i < n; i++) {
            final int r = pty.writePty(fd, del, 1);
            if (r == 1) {
                res[0]++;
            } else {
                res[1]++;
            }
        }
        return res;
    }

    public synchronized void printLocal(String s) {
        processChunk(s);
        notifySnapshot();
    }

    private void readLoop() {
        final byte[] buf = new byte[4096];
        while (running) {
            final int r = pty.readPty(fd, buf, buf.length);
            if (r > 0) {
                try {
                    final String s = new String(buf, 0, r, "UTF-8");
                    if (TAP_RX) {
                        EventLog.append(appCtx, "pty-rx", "len=" + s.length() + " [" + escapeChunk(s) + "]");
                    }
                    synchronized (ShellSession.this) {
                        processChunk(s);
                        notifySnapshot();
                    }
                } catch (UnsupportedEncodingException e) {
                    // ignore partial sequences
                }
            } else if (r < 0) {
                final ArrayList<Listener> copy;
                synchronized (ShellSession.this) {
                    running = false;
                    copy = copyListeners();
                }
                EventLog.append(appCtx, "pty", "closed");
                for (int i = 0; i < copy.size(); i++) {
                    final Listener l = (Listener) copy.get(i);
                    mainHandler.post(new Runnable() {
                        public void run() {
                            l.onClosed();
                        }
                    });
                }
            } else {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    synchronized (ShellSession.this) {
                        running = false;
                    }
                }
            }
        }
    }

    private ArrayList<Listener> copyListeners() {
        final ArrayList<Listener> copy = new ArrayList<Listener>();
        for (int i = 0; i < listeners.size(); i++) {
            copy.add((Listener) listeners.get(i));
        }
        return copy;
    }

    private static String escapeChunk(final String s) {
        final StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c == '\r') {
                sb.append("\\r");
            } else if (c == '\n') {
                sb.append("\\n");
            } else if (c == '\b') {
                sb.append("\\b");
            } else if (c == '\t') {
                sb.append("\\t");
            } else if (c == 27) {
                sb.append("\\e");
            } else if (c == 7) {
                sb.append("\\a");
            } else if (c < 32 || c == 127) {
                sb.append("\\x");
                sb.append(Character.forDigit((c >> 4) & 15, 16));
                sb.append(Character.forDigit(c & 15, 16));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private void notifySnapshot() {        final String snap = transcript.toString();
        final ArrayList<Listener> copy = copyListeners();
        if (mainHandler == null) {
            return;
        }
        for (int i = 0; i < copy.size(); i++) {
            final Listener l = (Listener) copy.get(i);
            mainHandler.post(new Runnable() {
                public void run() {
                    l.onOutput(snap);
                }
            });
        }
    }

    private void truncateLine() {
        final int nl = transcript.lastIndexOf("\n");
        transcript.delete(nl + 1, transcript.length());
    }

    private void processChunk(final String s) {
        int i = 0;
        int n = s.length();
        if (pendingCR) {
            pendingCR = false;
            if (n == 0) {
                pendingCR = true;
                return;
            }
            if (n > 0 && s.charAt(0) == '\n') {
                transcript.append('\n');
                i = 1;
            } else {
                // A CR run may continue across the chunk boundary: fold it
                // with the same rule as below instead of truncating blindly.
                int j = 0;
                while (j < n && s.charAt(j) == '\r') {
                    j++;
                }
                if (j < n && s.charAt(j) == '\n') {
                    i = j;
                } else if (j >= n && n > 0) {
                    pendingCR = true;
                    i = n;
                } else {
                    truncateLine();
                }
            }
        }
        while (i < n) {
            final char c = s.charAt(i);
            if (c == '\b') {
                final int len = transcript.length();
                if (len > 0 && transcript.charAt(len - 1) != '\n') {
                    transcript.deleteCharAt(len - 1);
                }
                i++;
            } else if (c == '\r') {
                // Fold runs: \r\r*\n is ONLCR-doubled CRLF (newline only), a
                // lone \r followed by text is a redraw (truncate once).
                int j = i;
                while (j < n && s.charAt(j) == '\r') {
                    j++;
                }
                if (j < n && s.charAt(j) == '\n') {
                    i = j;
                    continue;
                } else if (j >= n) {
                    pendingCR = true;
                    i = n;
                } else {
                    truncateLine();
                    i = j;
                }
            } else if (c == '\t') {
                final int lineLen = transcript.length() - (transcript.lastIndexOf("\n") + 1);
                int spaces = 8 - (lineLen % 8);
                for (int k = 0; k < spaces; k++) {
                    transcript.append(' ');
                }
                i++;
            } else if (c == 27) {
                int j = i + 1;
                if (j < n && s.charAt(j) == '[') {
                    j++;
                    while (j < n) {
                        final char d = s.charAt(j);
                        j++;
                        if (d >= '@' && d <= '~') {
                            break;
                        }
                    }
                } else if (j < n && s.charAt(j) == ']') {
                    // OSC: consume until BEL or ESC-backslash.
                    j++;
                    while (j < n) {
                        final char d = s.charAt(j);
                        if (d == 7) {
                            j++;
                            break;
                        }
                        if (d == 27 && j + 1 < n && s.charAt(j + 1) == '\\') {
                            j += 2;
                            break;
                        }
                        j++;
                    }
                } else if (j < n) {
                    j++;
                }
                i = j;
            } else if (c < 32 && c != '\n') {
                i++;
            } else {
                transcript.append(c);
                i++;
            }
        }
        if (transcript.length() > TRANSCRIPT_CAP) {
            transcript.delete(0, transcript.length() - TRANSCRIPT_CAP);
            final int nl = transcript.indexOf("\n");
            if (nl >= 0) {
                transcript.delete(0, nl + 1);
            }
        }
    }
}
