package com.aetherix.shell;

/**
 * JNI to libptyjni (openpty). Mirrors hermes terminal.py queue/winsize/PDEATHSIG.
 * writePty added for test-install shell input. loadLibrary wrapped by callers
 * (TerminalActivity) so a missing .so shows text instead of crashing.
 * No lambdas/diamonds.
 */
public class PtyBridge {
    private static boolean loaded = false;
    private static String loadError = "";
    public static synchronized boolean ensureLoaded() {
        if (loaded) {
            return true;
        }
        try {
            System.loadLibrary("ptyjni");
            loaded = true;
            return true;
        } catch (UnsatisfiedLinkError e) {
            loadError = e.getMessage();
            return false;
        }
    }
    public static String getLoadError() {
        return loadError;
    }
    public native int openPty(String cmd, String cwd, String[] env);
    public native int readPty(int fd, byte[] buf, int len);
    public native int writePty(int fd, byte[] buf, int len);
    public native void resizePty(int fd, int rows, int cols);
    public native void closePty(int fd);
}
