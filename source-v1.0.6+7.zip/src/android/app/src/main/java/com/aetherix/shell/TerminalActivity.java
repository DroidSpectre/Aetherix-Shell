package com.aetherix.shell;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

/**
 * Thin view over ShellSession (process-owned shell, Termux-style).
 * v21: activity no longer owns the PTY - it attaches/detaches for display
 * while EnvService keeps the session alive across app/task state changes.
 * Display processing, transcript, and reader live in the session.
 * Keybar trimmed to ESC/TAB/CTRL/arrows/special per feedback; CTRL unlatches
 * on ANY subsequent input (stuck-latch fix). Keyboard show retried delayed.
 * Shell is the on-device /system/bin/sh. Tap output reopens keyboard.
 * No lambdas, no diamonds.
 */
public class TerminalActivity extends Activity {
    private TextView output = null;
    private ScrollView scroll = null;
    private PtyEditText catcher = null;
    private LinearLayout root = null;
    private Button ctrlBtn = null;
    private volatile boolean ctrlLatched = false;
    private boolean selecting = false;

    private final ShellSession.Listener sessionListener = new ShellSession.Listener() {
        public void onOutput(String transcriptSnapshot) {
            output.setText(transcriptSnapshot);
            scrollToBottom();
        }
        public void onClosed() {
            try {
                output.setText(output.getText() + "\n[pty closed - reopen terminal]\n");
            } catch (Exception ignored) {
            }
            scrollToBottom();
        }
    };

    private int themeColor(int attr, int fallback) {
        try {
            final android.util.TypedValue tv = new android.util.TypedValue();
            if (getTheme().resolveAttribute(attr, tv, true)) {
                return tv.data;
            }
        } catch (Exception ignored) {
        }
        return fallback;
    }

    public void onCreate(Bundle savedInstanceState) {
        CrashLog.install(this);
        super.onCreate(savedInstanceState);
        final int fg = themeColor(android.R.attr.textColorPrimary, 0xFF212121);
        final int hint = themeColor(android.R.attr.textColorHint, 0xFF757575);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // Edge-to-edge (targetSdk 35): manual insets, framework auto-padding off.
        root.setFitsSystemWindows(false);
        final LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        final TextView barTitle = new TextView(this);
        barTitle.setText("Aetherix shell");
        barTitle.setTextColor(fg);
        barTitle.setClickable(true);
        barTitle.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                toggleKeyboard();
            }
        });
        final LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        bar.addView(barTitle, titleLp);
        final Button paste = new Button(this);
        paste.setText("Paste");
        paste.setTextColor(fg);
        bar.addView(paste, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        paste.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                pasteFromClipboard();
            }
        });
        scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(false);
        scroll.setFillViewport(true);
        output = new TextView(this);
        output.setTypeface(android.graphics.Typeface.MONOSPACE);
        output.setTextSize(12.0f);
        output.setTextColor(fg);
        output.setHintTextColor(hint);
        // Single-focus rule (v6): the catcher is the sole lifetime IME owner.
        // Output is NOT selectable by default; long-press enters an explicit
        // selection mode (copy handles), Back exits and returns focus.
        output.setTextIsSelectable(false);
        scroll.addView(output, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // CRT frame: 2dp electric-green border around the screen. Inner bg follows
        // ThemeAetherix (black in night, white in day) so DayNight keeps working.
        final LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(0xFF39FF14);
        final int edge = (int) (2.0f * getResources().getDisplayMetrics().density + 0.5f);
        screen.setPadding(edge, edge, edge, edge);
        final int nightMask = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        final boolean night = nightMask == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        scroll.setBackgroundColor(night ? 0xFF121212 : 0xFFFFFFFF);
        screen.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        root.addView(screen, scrollLp);
        buildKeybar();
        catcher = new PtyEditText(this);
        final LinearLayout.LayoutParams catchLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
        root.addView(catcher, catchLp);
        if (android.os.Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try {
                        // API 30+: include the IME inset so the prompt clears the
                        // keyboard even when adjustResize does not shrink us.
                        final int top;
                        final int bottom;
                        if (android.os.Build.VERSION.SDK_INT >= 30) {
                            final android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars());
                            final android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
                            top = bars.top;
                            final int sysBottom = bars.bottom;
                            final int imeBottom = ime.bottom;
                            bottom = sysBottom > imeBottom ? sysBottom : imeBottom;
                        } else {
                            top = insets.getSystemWindowInsetTop();
                            bottom = insets.getSystemWindowInsetBottom();
                        }
                        v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), bottom);
                        scroll.post(new Runnable() {
                            public void run() {
                                scroll.fullScroll(View.FOCUS_DOWN);
                            }
                        });
                    } catch (Exception ignored) {
                    }
                    return insets;
                }
            });
        }
        output.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showKeyboard();
            }
        });
        output.setOnLongClickListener(new View.OnLongClickListener() {
            public boolean onLongClick(View v) {
                selecting = true;
                output.setTextIsSelectable(true);
                output.requestFocus();
                EventLog.append(TerminalActivity.this, "selection", "enter");
                // Return false: the TextView's own long-press handling is
                // what raises the selection handles. Consuming the event
                // (true) vibrates but never selects - the v6 field finding.
                return false;
            }
        });
        catcher.setSink(new PtyEditText.Sink() {
            public void sendText(String s, String src) {
                final boolean hadCtrl = ctrlLatched;
                setCtrl(false);
                if (hadCtrl && s.length() == 1) {
                    final char c = s.charAt(0);
                    int code = -1;
                    if (c >= 'a' && c <= 'z') {
                        code = c - 96;
                    } else if (c >= 'A' && c <= 'Z') {
                        code = c - 64;
                    }
                    if (code >= 0) {
                        if (ensureSession() == false) {
                            return;
                        }
                        final int w = ShellSession.get().writeText(String.valueOf((char) code));
                        EventLog.append(TerminalActivity.this, "input", "[" + src + "] ctrl code=" + code + " wrote=" + w);
                        return;
                    }
                }
                if (ensureSession() == false) {
                    return;
                }
                final int wrote = ShellSession.get().writeText(s);
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] text len=" + s.length() + " wrote=" + wrote);
            }
            public void sendDel(int n, String src) {
                setCtrl(false);
                if (ensureSession() == false) {
                    return;
                }
                final int[] r = ShellSession.get().writeDel(n);
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] del n=" + n + " wrote=" + r[0] + " err=" + r[1]);
            }
            public void sendEnter(String src) {
                setCtrl(false);
                if (ensureSession() == false) {
                    return;
                }
                // Terminals expect CR; the kernel maps it per ICRNL. Writing LF
                // worked only while everything stayed in cooked mode.
                final int w = ShellSession.get().writeText("\r");
                EventLog.append(TerminalActivity.this, "input", "[" + src + "] enter wrote=" + w);
            }
        });
        setContentView(root);
        PtyBridge.ensureLoaded();
        ShellSession.get().start(getApplicationContext());
        showKeyboard();
    }

    public void onResume() {
        super.onResume();
        // A dead session (user typed exit) stays dead until restarted - reopen
        // must revive it instead of attaching to a corpse.
        if (ShellSession.get().isRunning() == false) {
            EventLog.append(this, "pty", "restart after death");
            ShellSession.get().start(getApplicationContext());
        }
        ShellSession.get().attach(sessionListener);
        rebindKeyboard();
    }

    public void onPause() {
        try {
            ShellSession.get().detach(sessionListener);
        } catch (Exception ignored) {
        }
        super.onPause();
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            rebindKeyboard();
        }
    }

    /**
     * Trimmed keybar: ESC / TAB / CTRL latch / arrows / reserved special.
     * Symbols left to the soft keyboard. CTRL clears on any next input.
     */
    private void buildKeybar() {
        final int fg = themeColor(android.R.attr.textColorPrimary, 0xFF212121);
        final android.widget.HorizontalScrollView hscroll = new android.widget.HorizontalScrollView(this);
        final LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        final String[] labels = new String[] {"ESC", "TAB", "CTRL", "⬅️", "⬆️", "⬇️", "➡️", "✨️"};
                // Control bytes built from char codes (27=ESC, 9=TAB) so no invisible
        // literals live in source. Arrows are CSI sequences, Termux-compatible.
        final String esc = String.valueOf((char) 27);
        final String[] codes = new String[] {esc, String.valueOf((char) 9), null, esc + "[D", esc + "[A", esc + "[B", esc + "[C", null};
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            final Button b = new Button(this);
            b.setText(labels[idx]);
            b.setTextColor(fg);
            b.setTextSize(12.0f);
            b.setMinWidth(0);
            b.setMinimumWidth(0);
            if (idx == 2) {
                ctrlBtn = b;
            }
            b.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    onKeybarPress(idx, codes);
                }
            });
            keys.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        hscroll.addView(keys, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(hscroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void onKeybarPress(final int idx, final String[] codes) {
        if (idx == 2) {
            setCtrl(ctrlLatched == false);
            return;
        }
        if (idx == 7) {
            EventLog.append(this, "keybar", "special reserved");
            return;
        }
        setCtrl(false);
        sendKey(codes[idx]);
    }

    private void setCtrl(final boolean on) {
        // Log transitions only: the old always-log drowned real events
        // (every keystroke printed a ctrl-off line).
        if (ctrlLatched == on) {
            return;
        }
        ctrlLatched = on;
        try {
            if (ctrlBtn != null) {
                ctrlBtn.post(new Runnable() {
                    public void run() {
                        try {
                            ctrlBtn.setBackgroundColor(on ? 0xFF39FF14 : 0x00000000);
                        } catch (Exception ignored) {
                        }
                    }
                });
            }
        } catch (Exception ignored) {
        }
        EventLog.append(this, "keybar", on ? "ctrl on" : "ctrl off");
    }

    private void sendKey(final String seq) {
        if (seq == null) {
            return;
        }
        if (ensureSession() == false) {
            return;
        }
        final int w = ShellSession.get().writeText(seq);
        EventLog.append(this, "keybar", "len=" + seq.length() + " wrote=" + w);
    }

    // Attach telemetry (v6): focus holder, window focus, and whether the IME
    // is actively serving this view, on every keyboard transition. The tagged
    // log then discriminates focus contests from dead bindings in the field.
    private void logIme(String where) {
        try {
            final boolean f = catcher.hasFocus();
            final boolean wf = catcher.hasWindowFocus();
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            final boolean acc = imm != null && imm.isAcceptingText();
            EventLog.append(this, "ime", where + " focus=" + f + " win=" + wf + " acc=" + acc);
        } catch (Exception ignored) {
        }
    }

    private void scrollToBottom() {        scroll.post(new Runnable() {
            public void run() {
                scroll.fullScroll(View.FOCUS_DOWN);
                // Never steal selection: in selection mode the output owns
                // focus by design (single-focus rule, mode-swapped).
                if (selecting) {
                    return;
                }
                try {
                    final int a = output.getSelectionStart();
                    final int b = output.getSelectionEnd();
                    if (a == b && catcher.hasFocus() == false) {
                        catcher.requestFocus();
                    }
                } catch (Exception e) {
                    try {
                        catcher.requestFocus();
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    /**
     * Revive-after-exit: typing into a dead shell (user ran exit) starts a
     * fresh one instead of swallowing input. Returns live state.
     */
    private boolean ensureSession() {
        try {
            final ShellSession s = ShellSession.get();
            if (s.isRunning()) {
                return true;
            }
            s.start(getApplicationContext());
            final boolean ok = s.isRunning();
            EventLog.append(this, "pty", ok ? "revived on input" : "revive failed");
            return ok;
        } catch (Exception e) {
            return false;
        }
    }

    private void showKeyboard() {
        // Single attempt, no retry timers: speculative re-shows destabilize
        // live Gboard bindings. Triggers are tap, resume, and window focus.
        directShow();
    }

    /**
     * Idempotent connect: if the IME is already bound to the catcher, touch
     * nothing. Every previous version rebound unconditionally, so a tap meant
     * to fix a dead keyboard could kill a live one - the fragility reported.
     * Tap, resume, and focus paths all funnel here.
     */
    private void ensureKeyboard() {
        logIme("ensure");
        try {
            // Idempotent: a live binding is never touched (v26 lesson kept).
            if (imeAlive()) {
                return;
            }
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (catcher.hasFocus() == false) {
                catcher.requestFocus();
            }
            // State gate, not time gate: repair only when the window can
            // serve (focus + window focus) but the IME is not serving this
            // view. Elapsed-time cooldowns stood down on dead bindings.
            if (catcher.hasFocus() && catcher.hasWindowFocus() && imm != null && imm.isAcceptingText() == false) {
                logIme("repair");
                catcher.clearFocus();
                catcher.requestFocus();
                imm.restartInput(catcher);
            }
            if (imm != null) {
                imm.showSoftInput(catcher, InputMethodManager.SHOW_IMPLICIT);
            }
        } catch (Exception ignored) {
        }
    }

    private void toggleKeyboard() {
        // Title tap: explicit show/hide independent of system nav cosmetics.
        logIme("toggle");
        try {
            if (imeAlive()) {
                final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(catcher.getWindowToken(), 0);
                }
            } else {
                ensureKeyboard();
            }
        } catch (Exception ignored) {
        }
    }

    private boolean imeAlive() {
        try {
            if (catcher.hasFocus() == false || catcher.hasWindowFocus() == false) {
                return false;
            }
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            return imm != null && imm.isAcceptingText();
        } catch (Exception e) {
            return false;
        }
    }

    private void directShow() {
        logIme("direct");
        try {
            catcher.clearFocus();
            catcher.requestFocus();
            final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.restartInput(catcher);
            imm.showSoftInput(catcher, InputMethodManager.SHOW_IMPLICIT);
        } catch (Exception ignored) {
        }
    }

    private void rebindKeyboard() {
        ensureKeyboard();
    }

    private void pasteFromClipboard() {
        // Foreground tap counts as user-driven, so clipboard read is allowed.
        try {
            final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || cm.hasPrimaryClip() == false) {
                ShellSession.get().printLocal("[clipboard empty]\n");
                return;
            }
            final android.content.ClipData clip = cm.getPrimaryClip();
            if (clip == null || clip.getItemCount() == 0) {
                ShellSession.get().printLocal("[clipboard empty]\n");
                return;
            }
            final CharSequence t = clip.getItemAt(0).coerceToText(this);
            if (t == null || t.length() == 0) {
                ShellSession.get().printLocal("[clipboard empty]\n");
                return;
            }
            // Normalize line endings only; every other byte goes verbatim.
            final String raw = t.toString();
            final String norm = raw.replace("\r\n", "\n").replace('\r', '\n');
            if (ensureSession() == false) {
                ShellSession.get().printLocal("[shell not running]\n");
                return;
            }
            final int w = ShellSession.get().writeText(norm);
            ShellSession.get().printLocal("[pasted " + norm.length() + " chars]\n");
            EventLog.append(this, "paste", "chars=" + norm.length() + " wrote=" + w);
        } catch (Exception e) {
            ShellSession.get().printLocal("[paste blocked: " + String.valueOf(e.getMessage()) + "]\n");
            EventLog.append(this, "paste", "blocked: " + String.valueOf(e.getMessage()));
        }
    }

    public void onBackPressed() {
        // Selection mode exits first: drop copy handles, return focus to the
        // sole IME owner (transition-gated rebind, not a storm).
        if (selecting) {
            selecting = false;
            output.setTextIsSelectable(false);
            EventLog.append(this, "selection", "exit");
            // Refocus first: field log showed the exit rebind observing
            // focus=false and standing down for a pass.
            catcher.requestFocus();
            rebindKeyboard();
            return;
        }
        // Session lives in the service process now, so parking is even safer:
        // reopen attaches to the same live transcript.
        try {
            final android.content.Intent i = new android.content.Intent(this, MainActivity.class);
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        } catch (Exception e) {
            try {
                moveTaskToBack(true);
            } catch (Exception ignored) {
                super.onBackPressed();
            }
        }
    }

    public void onDestroy() {
        // Detach only: the session outlives the activity by design.
        try {
            ShellSession.get().detach(sessionListener);
        } catch (Exception ignored) {
        }
        EventLog.append(this, "pty", "activity destroy (session kept)");
        super.onDestroy();
    }
}
