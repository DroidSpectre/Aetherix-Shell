package com.aetherix.shell;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Launcher: starts EnvService (guarded), shows live status + event/crash logs.
 * Back minimizes the task (paired with TerminalActivity Back-to-launcher, so
 * the two screens never trap each other and the shell session survives).
 * Copy log / Share log make field reports copyable without logcat.
 * No lambdas, no diamonds.
 */
public class MainActivity extends Activity {
    private TextView status = null;

    public void onCreate(Bundle savedInstanceState) {
        CrashLog.install(this);
        super.onCreate(savedInstanceState);
        EventLog.append(this, "app", "launcher create");
        final LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // Edge-to-edge (targetSdk 35): pad top manually so the title clears the status bar.
        root.setFitsSystemWindows(false);
        final TextView title = new TextView(this);
        title.setText("Aetherix-Shell");
        title.setTextSize(20.0f);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        status = new TextView(this);
        status.setText("starting...");
        status.setTextIsSelectable(true);
        root.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f));
        final Button open = new Button(this);
        open.setText("Open terminal");
        root.addView(open, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        final LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final Button copy = new Button(this);
        copy.setText("Copy");
        final LinearLayout.LayoutParams third = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        row.addView(copy, third);
        final Button share = new Button(this);
        share.setText("Share");
        row.addView(share, third);
        final Button clear = new Button(this);
        clear.setText("Clear");
        row.addView(clear, third);
        root.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        if (android.os.Build.VERSION.SDK_INT >= 20) {
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                    try {
                        final int top = insets.getSystemWindowInsetTop();
                        final int bottom = insets.getSystemWindowInsetBottom();
                        v.setPadding(v.getPaddingLeft(), top, v.getPaddingRight(), bottom);
                    } catch (Exception ignored) {
                    }
                    return insets;
                }
            });
        }
        try {
            final Intent svc = new Intent(this, EnvService.class);
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(svc);
                } else {
                    startService(svc);
                }
            } catch (Exception e) {
                try {
                    startService(svc);
                } catch (Exception ignored) {
                }
            }
        } catch (Exception e) {
            status.setText("service start blocked: " + String.valueOf(e.getMessage()));
        }
        open.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    final Intent i = new Intent(MainActivity.this, TerminalActivity.class);
                    startActivity(i);
                } catch (Exception e) {
                    status.setText("terminal blocked: " + String.valueOf(e.getMessage()));
                }
            }
        });
        copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyLog();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                shareLog();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                clearLog();
            }
        });
        refresh();
    }

    public void onResume() {
        super.onResume();
        refresh();
    }

    public void onBackPressed() {
        // Terminal Back comes here; our Back leaves the app so neither screen traps the other.
        try {
            moveTaskToBack(true);
        } catch (Exception e) {
            super.onBackPressed();
        }
    }

    private String buildReport() {
        final boolean nativeOk = PtyBridge.ensureLoaded();
        final String events = EventLog.readTail(MainActivity.this, 2000);
        final String crash = CrashLog.readTail(MainActivity.this, 1500);
        // Never hardcode: v15-v18 all displayed a stale literal, hiding which
        // build was actually under test. Read the real package version.
        String vname = "?";
        int vcode = -1;
        try {
            final android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            vname = pi.versionName;
            vcode = pi.versionCode;
        } catch (Exception ignored) {
        }
        final String head = "Aetherix-Shell " + vname + "+" + vcode + " / android " + String.valueOf(Build.VERSION.RELEASE) + " (sdk " + String.valueOf(Build.VERSION.SDK_INT) + ")\nnative: " + (nativeOk ? "ok" : ("missing: " + PtyBridge.getLoadError()));
        final String ev = events.length() > 0 ? events : "(no events yet)";
        final String cr = crash.length() > 0 ? crash : "(no recorded crashes)";
        return head + "\n--- events ---\n" + ev + "\n--- last crash ---\n" + cr;
    }

    private void refresh() {
        final Thread t = new Thread(new Runnable() {
            public void run() {
                final String msg = buildReport();
                runOnUiThread(new Runnable() {
                    public void run() {
                        status.setText(msg);
                    }
                });
            }
        });
        t.start();
    }

    private void copyLog() {
        try {
            final String text = status.getText().toString();
            final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("aetherix-log", text));
            EventLog.append(this, "app", "log copied");
        } catch (Exception e) {
            status.setText("copy blocked: " + String.valueOf(e.getMessage()));
        }
    }

    private void clearLog() {
        try {
            final java.io.File ev = new java.io.File(getFilesDir(), EventLog.NAME);
            ev.delete();
            final java.io.File cr = new java.io.File(getFilesDir(), CrashLog.NAME);
            cr.delete();
            EventLog.append(this, "app", "logs cleared");
            refresh();
        } catch (Exception e) {
            status.setText("clear blocked: " + String.valueOf(e.getMessage()));
        }
    }

    private void shareLog() {
        try {
            final String text = status.getText().toString();
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(i, "Share Aetherix log"));
            EventLog.append(this, "app", "log shared");
        } catch (Exception e) {
            status.setText("share blocked: " + String.valueOf(e.getMessage()));
        }
    }
}
