package com.aetherix.shell;

import android.content.Context;
import android.os.Build;
import android.text.Editable;
import android.text.InputType;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;

/**
 * 1px IME catcher with Termux-style dual-path input, clean-room implementation.
 * No Termux code is used or copied; only the public technique (TYPE_NULL to
 * request key events, text commits as fallback) is applied with original code.
 *
 * Why two paths: Gboard sends key events (not text) when the field requests
 * TYPE_NULL, while Hacker's Keyboard, OpenBoard, and LG send commitText
 * regardless. Either route reaches the Sink exactly once: key events never
 * produce commits under TYPE_NULL, and commit keyboards never produce key
 * events, so the paths do not overlap.
 * Visible-password is gone (it hid Gboard's clipboard UI and still left
 * autocorrect-adjacent composition bursts); TYPE_NULL requests raw keys.
 * No lambdas, no diamonds.
 */
public class PtyEditText extends EditText {
    public interface Sink {
        void sendText(String s, String src);
        void sendDel(int n, String src);
        void sendEnter(String src);
    }

    private Sink sink = null;

    public PtyEditText(Context ctx) {
        super(ctx);
        setBackgroundColor(0x00000000);
        setTextColor(0x00000000);
        setCursorVisible(false);
        // Termux discipline: TYPE_NULL by default (raw key events); Samsung
        // keyboards do not reset state on TYPE_NULL, so they get password mode.
        setInputType(chooseInputType());
        setImeOptions(EditorInfo.IME_ACTION_NONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
    }

    private static int chooseInputType() {
        try {
            if ("samsung".equalsIgnoreCase(Build.MANUFACTURER)) {
                return InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
            }
        } catch (Exception ignored) {
        }
        return InputType.TYPE_NULL;
    }

    public void setSink(Sink s) {
        sink = s;
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        // Primary path under TYPE_NULL: hardware keys and Gboard-class soft
        // keyboards deliver printable characters, DEL, and ENTER as key events.
        // CommitText keyboards never reach here, so there is no double-send.
        try {
            final int action = event.getAction();
            if (sink != null && (action == KeyEvent.ACTION_DOWN || action == KeyEvent.ACTION_MULTIPLE)) {
                final int kc = event.getKeyCode();
                if (kc == KeyEvent.KEYCODE_DEL) {
                    sink.sendDel(1, "key");
                    return true;
                }
                if (kc == KeyEvent.KEYCODE_ENTER) {
                    sink.sendEnter("key");
                    return true;
                }
                if (action == KeyEvent.ACTION_MULTIPLE && kc == KeyEvent.KEYCODE_UNKNOWN) {
                    final CharSequence ch = event.getCharacters();
                    if (ch != null && ch.length() > 0) {
                        sink.sendText(ch.toString(), "key");
                        return true;
                    }
                }
                if (action == KeyEvent.ACTION_DOWN) {
                    // Strip ctrl/alt: ctrl is our keybar latch, alt rarely
                    // intended in a phone terminal; the printable char remains.
                    final int mask = KeyEvent.META_CTRL_MASK | KeyEvent.META_ALT_MASK | KeyEvent.META_ALT_LEFT_ON | KeyEvent.META_ALT_RIGHT_ON;
                    final int effectiveMeta = event.getMetaState() & ~mask;
                    final int uni = event.getUnicodeChar(effectiveMeta);
                    if (uni != 0 && (uni & KeyCharacterMap.COMBINING_ACCENT) == 0) {
                        sink.sendText(String.valueOf((char) uni), "key");
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return super.dispatchKeyEvent(event);
    }

    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
        outAttrs.inputType = chooseInputType();
        outAttrs.imeOptions = EditorInfo.IME_ACTION_NONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI;
        super.onCreateInputConnection(outAttrs);
        return new PtyConnection(this, true);
    }

    private class PtyConnection extends BaseInputConnection {

        PtyConnection(View v, boolean full) {
            super(v, full);
        }

        private void drainEditable(String src) {
            try {
                final Editable e = getEditable();
                if (e != null && e.length() > 0) {
                    final String s = e.toString();
                    e.clear();
                    if (sink != null && s.length() > 0) {
                        sink.sendText(s, src);
                    }
                }
            } catch (Exception ignored) {
            }
        }

        public boolean commitText(CharSequence text, int newCursorPosition) {
            if (text == null) {
                return true;
            }
            super.commitText(text, newCursorPosition);
            // Drain-and-clear: the field holds the commit just long enough to
            // forward it exactly once. No pending state, no resends.
            drainEditable("commit");
            return true;
        }

        public boolean setComposingText(CharSequence text, int newCursorPosition) {
            // Stage only; the send happens at commit/finish. Never emit here.
            super.setComposingText(text, newCursorPosition);
            return true;
        }

        public boolean setComposingRegion(int start, int end) {
            // Some IMEs delete by selecting a range first. Drain-and-clear
            // keeps ranges empty in practice; any non-empty range still means
            // DELs, routed through the single sink funnel.
            if (end > start) {
                if (sink != null) {
                    sink.sendDel(end - start, "commit");
                }
            }
            return true;
        }

        public boolean finishComposingText() {
            super.finishComposingText();
            drainEditable("commit");
            return true;
        }

        public boolean deleteSurroundingText(int beforeLength, int afterLength) {
            // Normalized to DEL events: one funnel, no parallel delete paths.
            if (sink != null && beforeLength > 0) {
                sink.sendDel(beforeLength, "commit");
            }
            return true;
        }

        public boolean deleteSurroundingTextInCodePoints(int beforeLength, int afterLength) {
            return deleteSurroundingText(beforeLength, afterLength);
        }

        public CharSequence getTextBeforeCursor(int length, int flags) {
            // Plausible minimal context (termux-x11 practice): several IMEs
            // misbehave around empty context (stale sessions, dropped
            // attaches, aggressive prediction). A single space satisfies
            // their expectations without affecting the drain-and-clear flow.
            return " ";
        }

        public CharSequence getTextAfterCursor(int length, int flags) {
            return " ";
        }

        public CharSequence getSelectedText(int flags) {
            return "";
        }

        public boolean sendKeyEvent(KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                final int kc = event.getKeyCode();
                if (kc == KeyEvent.KEYCODE_DEL) {
                    if (sink != null) {
                        sink.sendDel(1, "commit-key");
                    }
                    return true;
                }
                if (kc == KeyEvent.KEYCODE_ENTER) {
                    if (sink != null) {
                        sink.sendEnter("commit-key");
                    }
                    return true;
                }
            }
            return super.sendKeyEvent(event);
        }

        public boolean performEditorAction(int action) {
            if (sink != null) {
                sink.sendEnter("commit");
            }
            return true;
        }
    }
}
