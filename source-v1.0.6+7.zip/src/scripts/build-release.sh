#!/bin/sh
# Build + archive release immutably, then git commit+tag. Never overwrites.
# Usage: scripts/build-release.sh
# Why: enforces version-code-as-directory + traceability. Fails if dir exists.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROP="$ROOT/next-version.properties"
CODE="$(grep '^versionCode=' "$PROP" | cut -d= -f2)"
NAME="$(grep '^versionName=' "$PROP" | cut -d= -f2)"
DIR="$ROOT/releases/v${CODE}-${NAME}+${CODE}"
if [ -d "$DIR" ] && [ -n "$(ls -A "$DIR" 2>/dev/null | grep -v '.gitkeep')" ]; then
  # Allow initial skeleton dir only if it has no APK yet; fail if APK exists (never overwrite).
  if ls "$DIR"/*.apk >/dev/null 2>&1; then
    echo "Release dir already has APK, refusing overwrite: $DIR" >&2
    exit 1
  fi
fi
mkdir -p "$DIR/docs-snapshot"
echo "TODO: ./gradlew :app:assembleRelease (needs Android SDK) -> copy app-release.apk to $DIR/Aetherix-Shell-v${NAME}+${CODE}.apk"
echo "TODO: write build-info.json, CHANGELOG.snippet.md, cp -r docs $DIR/docs-snapshot/"
echo "TODO: git add -A && git commit -m 'release v${CODE}-${NAME}+${CODE}' && git tag 'v${NAME}+${CODE}'"
echo "TODO: bump next-version.properties for next version (separate commit)"
echo "Release dir ready: $DIR"
# Mirror to device Downloads (one-way, non-fatal if sdcard unmounted).
sh "$ROOT/scripts/sync-to-downloads.sh" || echo "WARNING: sync-to-downloads failed" >&2
