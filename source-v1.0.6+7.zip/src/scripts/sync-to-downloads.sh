#!/bin/sh
# One-way mirror: internal /Aetherix-Shell-no_proot -> external /sdcard/Download/Aetherix-Shell-no_proot
# Why rsync (not cp -a): incremental, skips FUSE temp symlinks (.l2s.tmp_obj_*),
# tolerates FAT/sdcardfs (no perms/times/owner preservation).
# Usage: scripts/sync-to-downloads.sh [--full]
#   default: sync working tree + .git (fast incremental)
#   --full: also verifies with diff --exclude=.git
# Called from: .git/hooks/post-commit, scripts/build-apk-nogradle.sh, scripts/build-release.sh
# Safe to re-run; never writes back to internal. Fails loud if sdcard missing;
# callers guard with || so commit/build still succeed (hook prints WARNING).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${SYNC_DEST:-/sdcard/Download/Aetherix-Shell-no_proot}"
if [ ! -d "$ROOT/.git" ]; then echo "no .git in $ROOT" >&2; exit 1; fi
mkdir -p "$DEST"
# rsync flags: -r recursive, --delete mirror deletions, --exclude transient FUSE files,
# --no-perms --no-times --omit-dir-times: sdcardfs cannot chmod/utime dirs (Permission denied otherwise).
# -q quiet, but show summary at end.
rsync -r --delete \
  --exclude='.l2s.tmp_obj_*' \
  --exclude='build/' \
  --no-perms --no-times --omit-dir-times --no-owner --no-group \
  "$ROOT/" "$DEST/"
echo "SYNC OK: $ROOT -> $DEST"
if [ "${1:-}" = "--full" ]; then
  diff -r --brief --exclude=".git" --exclude="build" "$ROOT" "$DEST" && echo "VERIFY IDENTICAL (excl .git/build)"
fi
ls -ld "$DEST" | head -n 1
