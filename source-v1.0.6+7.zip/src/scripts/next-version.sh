#!/bin/sh
# Print next version from next-version.properties. No lambdas/diamonds (shell).
set -e
F="$(dirname "$0")/../next-version.properties"
CODE="$(grep '^versionCode=' "$F" | cut -d= -f2)"
NAME="$(grep '^versionName=' "$F" | cut -d= -f2)"
echo "v${CODE}-${NAME}+${CODE}"
