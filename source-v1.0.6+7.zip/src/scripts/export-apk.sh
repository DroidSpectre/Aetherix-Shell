#!/bin/sh
# Export a release APK to device Download folder via shared-storage FUSE (pathway A).
# Why cp, not bridge: /sdcard/Download is writable for normal filenames, no timeout, byte-verified.
# Caveat: dotfile names fail (Operation not permitted) - APK names are safe.
# Usage: scripts/export-apk.sh [release-dir] [dest-dir]
# Example: scripts/export-apk.sh releases/v6-1.5.0+6
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REL="${1:-$ROOT/releases/v1-1.0.0+1}"
DEST="${2:-/sdcard/Download}"
APK="$(ls "$REL"/Aetherix-Shell-*.apk 2>/dev/null | head -n 1)"
if [ -z "$APK" ]; then echo "no APK in $REL" >&2; exit 1; fi
cp "$APK" "$DEST/"
BASE="$(basename "$APK")"
cmp "$APK" "$DEST/$BASE" && echo "IDENTICAL: $DEST/$BASE"
apksigner verify "$DEST/$BASE" && echo "VERIFY OK"
ls -lh "$DEST/$BASE"
