#!/bin/sh
# Rebuild android/app/src/main/jniLibs/arm64-v8a/libptyjni.so without the NDK.
# Toolchain: host clang (Debian 14, aarch64 target) + JDK jni.h + multiarch
# headers. No sysroot needed: -nostdlib leaves libc refs undefined for the
# on-device loader, and tools/nativelib/libc.so (link-time only, never
# shipped) provides the LIBC version node, mirroring NDK import libs.
# Why versioned refs: the device loader only binds sym@LIBC; unversioned
# refs die with "cannot locate symbol" (v1 lesson). pty.c/errno_shim.c
# carry .symver lines; this script + build-apk's symbol gate enforce it.
# Usage: scripts/rebuild-native.sh
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JH="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-arm64}"
STUBDIR="${STUBDIR:-/tmp/aetherix-stub}"
mkdir -p "$STUBDIR"
clang --target=aarch64-linux-android -shared -nostdlib -fPIC -O2 \
  -Wno-incompatible-library-redeclaration \
  -I/usr/include -I/usr/include/aarch64-linux-gnu \
  "$ROOT/tools/nativelib/libc-stub.c" -o "$STUBDIR/libc.so" \
  -Wl,-soname,libc.so -Wl,--version-script,"$ROOT/tools/nativelib/libc.map"
OUT="$ROOT/android/app/src/main/jniLibs/arm64-v8a/libptyjni.so"
mkdir -p "$(dirname "$OUT")"
clang --target=aarch64-linux-android26 -shared -nostdlib -fPIC -O2 \
  -I"$JH/include" -I"$JH/include/linux" \
  -I/usr/include -I/usr/include/aarch64-linux-gnu \
  "$ROOT/android/app/src/main/jni/pty.c" "$ROOT/android/app/src/main/jni/errno_shim.c" \
  -o "$OUT" -Wl,-soname,libptyjni.so "$STUBDIR/libc.so"
echo "built $OUT"
nm -D "$OUT" | grep -c 'Java_com_aetherix_shell'
if nm -D "$OUT" | grep ' U ' | grep -qv '@'; then
  echo "UNVERSIONED REFS PRESENT - refusing" >&2
  exit 1
fi
echo "all refs versioned OK"
