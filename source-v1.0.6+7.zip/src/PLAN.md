# Aetherix-Shell-no_proot Plan

Lineage baseline: Aetherix-Debian v30-1.29.0+30 (field-proven terminal +
keyboard). This project starts at v1-1.0.0+1 with identical behavior under
the new package, minus proot/rootfs scaffolding, with the native lib rebuilt
for this package and gated by the build.

## Phase 0 - Clean repackage (this release, v1)

Why: a stable shell deserves its own version line; the Debian edition keeps
its numbering for the distribution track. How: derive from the v30 tag in
one pass (rename, strip, rebuilt `.so`, symbol gate, native-mismatch
hardening), fresh repo, build + archive + tag.
Verify: clean compile, style checks, gate firing, full APK pipeline, then
the same 10-test field battery as Debian v29/v30.

## Phase 1 - Shell hardening (next)

Candidate work, in order: survival edge cases, low-memory behavior, IME
edge keyboards (4+ apps matrix), EventLog off-UI-thread (BUG-AUDIT B4),
view-size PTY resize sync. No new features until the battery is green.

## Phase 2 - Careful additions (later)

Only after Phase 1: font size control, color scheme toggle, sessions list.
Each addition ships as its own immutable release with field notes.
Explicitly out: package management, language runtimes, networking tools -
those belong to the Debian edition.
