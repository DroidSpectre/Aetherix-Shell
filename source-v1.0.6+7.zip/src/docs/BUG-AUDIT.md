# Bug & issue register (full code audit, 2026-09-30, at v23)
Read: all 11 Java files, pty.c, manifest, res themes, gradle files,
app_config.json, all 7 scripts. Severity: critical / major / minor.

## Keyboard & input (reported problem area)

- K1 major: dual-path double-delivery unproven. v22 assumes each keyboard uses
  exactly one of key-events / commitText, but both log identically
  ("text len="), so the log cannot distinguish. Triplicated echo may be one
  key arriving twice (plus shell echo). Fix: tag source in logs (`key` vs
  `commit`) - one-line change per path (PtyEditText.java dispatchKeyEvent,
  PtyConnection.commitText).
- K2 major: focus can always split. Selectable output + 1px catcher = two IME
  targets; every mitigation (v13 refocus, v16/17 rebind+retry) fights symptoms.
  Termux has ONE view owning focus+connection for life - the bug class cannot
  occur there. Medium-term fix: output not focusable except explicit
  selection mode (long-press enters, Done/Back exits, focus returns).
- K3 major: showSoftInput pre-focus is silently ignored; retry timers (250ms)
  race window focus on slow devices. Contributes to must-tap-every-time.
  Gate retries on hasWindowFocus + imm.isAcceptingText() instead of blind delay.
- K4 minor: setCtrl(false) logs "ctrl off" on EVERY keystroke (see v22 log:
  ctrl-off/text pairs) - noise drowning real events. Log only transitions.
- K5 minor: getTextBeforeCursor lie (16 spaces) may confuse swipe/autocorrect
  residuals; acceptable under TYPE_NULL, revisit if odd commits appear.

## Display (reported problem area)

- D1 major (fixed v20/v21, record): raw TextView rendered nothing - erase was
  invisible by construction. Processor now handles BS/CR/TAB/CSI/OSC + straddle.
- D2 major: no dead-session restart. Typing `exit` ends the shell forever;
  reopen attaches to a dead session (only "[pty closed]" hint). onResume must
  restart a dead session (ShellSession.java start guard already allows it).
- D3 medium: full-transcript setText per chunk + no output coalescing - fast
  output (cat big file) will stutter/ANR. Coalesce to ~100ms batches.
- D4 medium: selection collapses on every update (setText replaces). Accepted
  tradeoff, recorded.
- D5 minor: UTF-8 split across 4KB reads yields U+FFFD. Carry trailing
  incomplete sequence to next chunk.
- D6 minor: transcript cap silently drops head. Acceptable, recorded.

## Session / lifecycle

- S1 medium: bootstrap stub ALWAYS fails (no asset) and logs ERROR each start,
  alarming users (seen in field logs). Gate on asset presence: report
  "rootfs pending (expected)" instead of ERROR until the tarball ships.
- S2 minor: RuntimeLauncher.launch builds a cmdline nobody executes; listener
  ignores it (EnvService.java:81). Dead feature - remove or wire to real exec.
- S3 minor: HostBridge returns not-implemented JSON; EnvService.noteStarted is
  dead. Remove both or schedule.
- S4 minor: refresh() spawns a thread per onResume with no cancellation;
  overlapping reports race (last-writer-wins, harmless).
- S5 minor: MainActivity.versionCode uses deprecated field (warning-only).

## Packaging / native / build

- B1 HIGH: scripts/build-apk-nogradle.sh is stale - documents/uses aapt v1 +
  android-26 link with no res/jniLibs handling, while real builds since v8 use
  aapt2/35 + flats + stored .so. Running it now yields a broken older APK.
  Rewrite to the v23 proven commands.
- B2 medium: version lives in THREE places (manifest, app_config.json,
  next-version.properties) - drift risk. Generate two from one.
- B3 medium: pty.c hardcodes execl("/bin/sh") then runs cmd string; works on
  test device but /bin/sh is absent on many Android builds. Try
  /system/bin/sh directly with fallback list.
- B4 medium: EventLog.append does file open/write/close on the UI thread per
  keystroke. Batch or move off-thread if input ever lags.
- B5 minor: pty.c ignores chdir/dup2 failures, slave<=2 edge, no JNI exception
  checks; resizePty fixed 24x80 (no view-size sync - matters for fullscreen
  apps later); master O_NONBLOCK + 50ms sleep adds latency + wakeups.
- B6 minor: tools/*.jar (28MB) committed to git - fine for self-containment,
  consider git-lfs if it grows.
- B7 low: INTERNET + REQUEST_IGNORE_BATTERY_OPTIMIZATIONS permissions are
  unused (no network code, no exemption intent). Remove or justify.
- B8 low: no R8 minification (D8 only) - fine now, note for later.

## Triplication verdict (v22 report)
Input log shows ~1 event/key at app layer, so bytes are likely single and the
x3 appears downstream (shell echo layers) or in transcription. K1 source tags
+ `cat -v` of a typed line will discriminate definitively.
