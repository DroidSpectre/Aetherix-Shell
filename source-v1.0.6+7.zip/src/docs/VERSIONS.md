# Versions

| Dir | versionCode | versionName | git tag | Contents | Status |
|-----|-------------|-------------|---------|----------|--------|
| releases/v1-1.0.0+1 | 1 | 1.0.0 | v1.0.0+1 | Clean repackage from Debian v30, 41KB APK in Download | superseded (unversioned native refs) |
| releases/v5-1.0.4+5 | 5 | 1.0.4 | v1.0.4+5 | Versioned native bindings, 41KB APK in Download | superseded (attach flakiness) |
| releases/v6-1.0.5+6 | 6 | 1.0.5 | v1.0.5+6 | Keyboard release, 41KB APK in Download | superseded (selection never raised) |
| releases/v7-1.0.6+7 | 7 | 1.0.6 | v1.0.6+7 | Selection fix + portrait, 41KB APK in Download | committed |

Rule: new APK -> new row + new dir, never overwrite. `build-info.json` holds git sha, sizes, tool versions. `docs-snapshot/` holds docs copy at release time. `source-<tag>.zip` holds rebuildable source at release time (see `scripts/archive-source.sh`; toolchain in `tools/` is pinned, keystore regenerates).
