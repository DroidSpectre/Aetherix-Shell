# Terminal

Native `TerminalView + libptyjni.so` only for v1. Pattern from `hermes api/terminal.py`: `os.openpty()+Popen(shell,cwd,env TERM=xterm-256color,own pgid)`, nonblock `fcntl+select` reader `Queue 2000` drop-oldest, winsize clamp `8-80 x 20-240`, `PR_SET_PDEATHSIG` reaper, `killpg SIGHUP/KILL`. JNI mirrors in C. `tmux` attach supported, `script` available. `sshd -D` means foreground no-daemonize (no systemd); kept as debug toggle `sshd -D -p 2222` (`root:proot`) for PC access only, not needed for local PTY. No WebView/websocket in v1 (defer).
