# Keyboard: Termux vs Aetherix (source-level comparison, 2026-09-30)
Source: termux-app master TerminalView.java (GPL-3.0 - techniques adapted,
no code copied; all Aetherix implementations remain original).

## 1. InputType policy (the biggest difference)
- Termux: prefers TYPE_NULL, but switches to
  `VISIBLE_PASSWORD|NO_SUGGESTIONS` on Samsung keyboards, which do not reset
  internal state on TYPE_NULL (#686). Per-manufacturer branching.
- Ours (v22+): TYPE_NULL always. A Samsung device gets the exact broken case
  Termux explicitly works around. Recommendation: branch on
  Build.MANUFACTURER (Samsung -> visible-password, else TYPE_NULL).

## 2. Editable as drain buffer vs always-empty field
- Termux: lets commits land (`super.commitText` first), drains the Editable to
  the terminal, then `clear()`s it. The IME always sees true state, so
  backspace/delete behave with zero hacks and no cursor lies.
- Ours: field forced empty forever + fake `getTextBeforeCursor` (16 spaces).
  Every delete path exists only because the lie invites it. This is the most
  likely root of remaining backspace variance across keyboards.
  Recommendation: adopt drain-and-clear; delete the fake context.

## 3. Delete normalization
- Termux: `deleteSurroundingText(l, r)` is converted to `l` DEL KeyEvents and
  routed down the key path - one DEL implementation, not three.
- Ours: three live DEL paths (view key event, connection key event,
  deleteSurroundingText) plus setComposingRegion fallback. Consolidate to one
  funnel fed by normalized events.

## 4. Enter mapping
- Termux: AOSP keyboards send `\n` as *text*; mapped to `\r` (what terminals
  expect; matters once any raw/full-screen program runs).
- Ours: writes `\n` (ICRNL currently saves us in cooked mode). Switch to `\r`
  for correctness headroom.

## 5. Keyboard show/hide discipline
- Termux: user-driven toggle (`onToggleSoftKeyboardRequest`), focus-based
  binding, single view (focus cannot split), NO speculative restartInput or
  retry timers. Long-press enters selection mode; tap exits it.
- Ours: retry timers + rebind-on-show + cross-view refocus dance. Each
  speculative restart is a chance to break a live Gboard binding (the v26
  cooldown and v27 idempotence limit the damage but keep the mechanism).
  Recommendation: user-driven toggle only (our title tap already exists -
  make it the primary path), rebind solely on observed death.

## 6. Focus architecture
- Termux: ONE view owns display+input+connection for life. Selection is a
  mode, not a second focusable view.
- Ours: TWO views (selectable output steals focus - the entire v13 bug
  class). Recorded in BUG-AUDIT.md K2; durable fix is output focusable only
  inside explicit selection mode.

## 7. Sessions (already matching)
- Both: process/service-owned sessions, attach/detach views, START_STICKY
  rebirth. Ours since v21. No gap.

## 8. Extras Termux has that we lack
- Volume-button Ctrl/Fn, Ctrl+Alt shortcuts, paste via context menu,
  autofill explicitly disabled (no toolbar popup over the prompt),
  accessibility description of screen content, pinch font scaling,
  cursor blink control. Piecemeal candidates, not structural.

## Proposed v-next (needs approval)
a. Drain-and-clear editable, delete fake cursor context.
b. Single DEL funnel (normalize-then-route).
c. Per-manufacturer inputType + `\n`->`\r` enter mapping.
d. Toggle-primary keyboard discipline, drop retry timers.
e. Keep service sessions, keybar, display processor as-is.
