# Build system (Gradle-free, CodeAssist model) - PROVEN v4

## Proven toolchain (v4-1.3.0+4, 17KB APK, verify OK)

## What CodeAssist does (tyron12233/CodeAssist, GPL-3.0, 1.9k stars)

No Gradle daemon. Projects are a declarative model compiled to an incremental task DAG with fingerprint up-to-date checks + bounded cache. Pure-Java tools (Eclipse JDT/ecj, D8/R8, apksigner) run in-process; native `aapt2` runs as subprocess. Legacy `app_config.json` (not `build.gradle`) holds app config in old versions; v3 uses `workspace.json + module.toml + android facet` + `ProjectImporter/BuildSystem` SPI. Pipeline (Android): `compileAidl? -> mergeResources -> aapt2Compile -> aapt2Link (+R/R.jar bytecode, not R.java) -> compileJava (ecj) -> dexBuilder (3 scopes, per-class/per-jar cache, bucketed merge, parallel workers capped by heap) -> mergeNativeLibs + mergeJavaResource (AGP packaging defaults) -> packageApk -> zipalign -> sign (apksigner)`. Deps resolved via Maven/BOM offline cache, variant-aware (matching buildType/flavors), R kept out of ext dex so resource edits only re-dex project layer.

## What this container has / lacks (probed 2026-09-28)

Have: Debian bookworm arm64 host, Python 3.11, Node v22.23.1, 64G free, Aetherix Java sources (8 files, no lambdas/diamonds), `pty.c`, manifest.
Lacks: everything to build APK — no `java/javac/ecj`, no `ANDROID_SDK`, no `platforms/android-35/android.jar`, no `build-tools/aapt2,d8,apksigner,zipalign,aidl`, no keystore, no dependency cache. `apt-cache` shows no SDK packages; `/usr/lib/android-sdk,/opt/android-sdk` absent.

## What Aetherix needs (no Gradle)

1. **JDK 17 headless** (`apt install openjdk-17-jdk-headless`): provides `javac` fallback. Prefer `ecj.jar` (Eclipse JDT batch, CodeAssist backend) for in-process compile + `CategorizedProblem` diagnostics. Our Java 6 style compiles with `-source 8 -target 8`.
2. **Android SDK cmdline-tools + platform + build-tools** (arm64): `platforms/android-35/android.jar` (compile classpath + D8 bootclasspath, opened once and reused per CodeAssist `ClassFileProviderFactory`), `build-tools/35/aapt2` (native arm64 subprocess), `d8`/`r8.jar` (pure-Java, `java -jar`), `apksigner.jar`, `zipalign`. No NDK needed (no strip; native `.so` packaged as-is like AGP-without-NDK).
3. **Project model**: `android/app_config.json` (CodeAssist-legacy compatible) mirroring `next-version.properties` + `AndroidManifest.xml` + sourceSets. Replaces `build.gradle` for on-device builds; Gradle files kept only for desktop/CI.
4. **Task runner**: `scripts/build-apk-nogradle.sh` implementing DAG: `resolve -> ecj -> d8 (project scope per-class incremental, ext scope content-hash cache in .aetherix-cache/) -> mergeResources -> aapt2 compile/link -> package -> zipalign -> apksigner`. Fingerprint inputs (mtime+size+sha) to skip up-to-date tasks, like CodeAssist engine.
5. **Deps**: v3 manual (local `libs/*.jar` + `android.jar` only, e.g. appcompat if vendored). Maven transitive/BOM/version-catalog in v4 (CodeAssist `GradleImport`/`dependency resolver` equivalent). Our v1 has zero external Java deps beyond `appcompat` (stub or vendor).
6. **Signing**: generate `debug.keystore` once (`keytool`), `apksigner sign --ks`, `adb install`. Release signing via `keystore.properties` (never committed) — CodeAssist export notes this has no faithful file expression, keep out of repo.

## Why not Gradle here

Gradle needs full JDK+SDK download + daemon heap, too heavy for phone and for this 1.5G-tmpfs container; CodeAssist ditched it for on-ramp + safety (no unsigned-code execution). We keep Gradle files for Studio/CI compat only; first-class path is the shell+D8 pipeline above, which also matches our Java-only/no-lambda constraint (ecj handles it, kotlinc not needed).
