# Changelog

## v7-1.0.6+7 (2026-10-02) - selection fix, portrait lock
* Long-press consumed the event before the TextView raised handles (vibrate,
  no selection): listener now returns false so framework selection starts.
  Portrait locked on both activities. Selection-exit refocuses the catcher
  before rebinding (field log showed a stood-down pass). Telemetry verdict:
  exactly one justified repair, no doubles, no crashes. APK 41KB.

## v6-1.0.5+6 (2026-10-02) - keyboard release
* Single-focus architecture: output selectable only inside long-press
  selection mode (Back exits, focus returns to the catcher); scroll updates
  never steal selection. Rebind state-gated on `isAcceptingText` instead of
  the 1.5 s cooldown. Attach telemetry (`ime` tag: focus/win/acc) on every
  transition. TAP_RX wiretap gated off; plausible cursor context. APK 41KB.

## v5-1.0.4+5 (2026-10-02) - versioned native bindings
* Clean-line v1 plus the real fix, in one release (codes 2-4 retired with the
  discarded diagnostic line). Device loader binds only `sym@LIBC`; our
  `-nostdlib` build emitted unversioned refs and died on `ioctl` at load.
  Fixed with a link-time `libc.so` stub (`tools/nativelib/`, never shipped)
  + deterministic `scripts/rebuild-native.sh` (byte-identical output).
  APK 41KB verify OK in Download. See releases/v5-1.0.4+5/build-info.json.

## v1-1.0.0+1 (2026-10-02) - clean repackage from Debian v30
* Standalone shell under `com.aetherix.shell`, derived from Debian
  v30-1.29.0+30 (10/10 field pass, Samsung + Android 16) in one pass.
  Proot/rootfs scaffolding stripped. Native lib rebuilt for this package
  (symbol gate in the build refuses any Java/native skew; mismatch
  degrades to a log line, never a crash loop). APK 41KB verify OK in
  Download. See releases/v1-1.0.0+1/build-info.json.
